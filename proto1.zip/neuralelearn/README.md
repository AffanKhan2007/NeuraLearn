# NeuraLearn Visual Tutor — code-generating lesson engine

This version preserves the original NeuraLearn UI and changes the teaching engine: the configured model generates a complete runnable HTML/CSS/vanilla-JavaScript lesson, with Konva.js available for canvas-based visuals. The generated program is loaded into a sandboxed iframe rather than converted into a generic list of boxes.

## Requirements
- Node.js 20 or newer.
- A configured model endpoint. Local Ollama is the default; an OpenAI-compatible endpoint can also be used.
- A modern browser. Narration uses browser speech synthesis, whose voices vary by operating system/browser.

## Run on Windows PowerShell
1. Open PowerShell in this folder.
2. Copy `.env.example` to `.env`.
3. For local inference, install Ollama and pull a code-capable model, for example `ollama pull qwen2.5-coder:7b`, then set `OLLAMA_MODEL=qwen2.5-coder:7b` in `.env`. Use a stronger model if it produces weak code or shallow teaching.
4. Start the server: `node server.mjs` (or `npm start`).
5. Open `http://127.0.0.1:4173`.

No API key is required when using Ollama locally. For a hosted OpenAI-compatible endpoint, configure `.env`:
```
LLM_PROVIDER=openai-compatible
LLM_BASE_URL=https://your-provider.example/v1
LLM_API_KEY=your-secret-key
LLM_MODEL=your-code-capable-model
```
Some providers, including Gemini's OpenAI-compatible API, may be usable through this endpoint format; use that provider's documented base URL and model identifier. Keep `.env` private and never place secrets in browser code.

## How the new engine works
- `POST /api/code-lesson` asks the configured model for a full standalone teaching program, not a JSON description of diagram nodes.
- The generated lesson chooses a representation appropriate to the topic: for example, a binary tree and traversal output, photosynthesis process, packet movement, address translation, or equation transformations.
- The lesson runs in an iframe with `sandbox="allow-scripts"` and without same-origin privileges. It cannot access the parent application's DOM or cookies. Generated code is still untrusted code; do not remove the sandbox or add `allow-same-origin` casually.
- The generated program reports chapter/beat events to the host. The host UI handles synchronized subtitles, browser narration, outline, progress, pause/resume/replay, speed control, and lesson-aware Q&A.
- The host retains the existing visual design and outer controls. No separate Next button is required.

## Honest limitations
This is a working code-generation architecture, not a guarantee that every model response is excellent. Lesson correctness, animation quality, and compliance with the event protocol depend on the selected model. Small local models may return incomplete HTML, use generic visuals, or miss a control message; a stronger code-capable model is recommended. Live generation against your own Gemini/API key has not been verified in this environment. Validate important course content before relying on it. Browser speech voices are platform-dependent.

This is a local-first starter, not a deployed multi-user SaaS. There is no account system, cloud persistence, billing, robust PDF parsing, or hosted deployment. The server binds to `127.0.0.1`. Before public deployment, add authentication, authorization, secure secret storage, HTTPS, rate limits, per-user quotas, upload parsing/scanning, privacy/data-retention controls, observability, and automated browser/content tests.

## Tests
Run `node --test`.
