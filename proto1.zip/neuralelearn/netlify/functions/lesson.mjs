import { modelCall, validateText, parseJson, validateLesson, currentModel, lessonSchemaHint } from './lib/engine.mjs';

const PROVIDER = () => (process.env.LLM_PROVIDER || 'ollama').toLowerCase();
const json = (statusCode, data) => ({
  statusCode,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  body: JSON.stringify(data),
});

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST.' });
  try {
    const body = JSON.parse(event.body || '{}');
    const topic = validateText(body.topic, 'Topic', 500);
    const source = typeof body.source === 'string' ? body.source.slice(0, 20000) : '';
    const level = typeof body.level === 'string' ? body.level.slice(0, 100) : 'Undergraduate engineering';
    const raw = await modelCall(`You are NeuraLearn, a rigorous patient professor and visual instructional designer. Learner level: ${level}. Create a complete teachable lesson. ${lessonSchemaHint}`, `Teach: ${topic}\nLearner level: ${level}\nOptional source notes (prioritize these, don't invent what is absent):\n${source || '(No notes supplied)'}`, true);
    const lesson = validateLesson(parseJson(raw), topic);
    return json(200, { lesson, provider: PROVIDER(), model: currentModel() });
  } catch (e) { return json(e.status || 500, { error: e.message || 'Unexpected server error.' }); }
};
