import { modelCall, validateText } from './lib/engine.mjs';
import { ASK_SYSTEM } from './lib/engine.mjs';

const json = (statusCode, data) => ({
  statusCode,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  body: JSON.stringify(data),
});

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST.' });
  try {
    const body = JSON.parse(event.body || '{}');
    const question = validateText(body.question, 'Question', 3000);
    const lesson = body.lesson && typeof body.lesson === 'object' ? body.lesson : {};
    const sceneIndex = Number.isInteger(body.sceneIndex) ? body.sceneIndex : 0;
    const scene = Array.isArray(lesson.scenes) ? lesson.scenes[sceneIndex] : null;
    const context = JSON.stringify({ title: lesson.title, goals: lesson.learningGoals, summary: lesson.summary, currentScene: scene, transition: scene?.transition, practice: lesson.practice }).slice(0, 18000);
    const answer = await modelCall(ASK_SYSTEM, `Lesson context:\n${context}\n\nLearner question: ${question}`);
    if (!answer.trim()) throw new Error('The model returned an empty answer.');
    return json(200, { answer: answer.trim() });
  } catch (e) { return json(e.status || 500, { error: e.message || 'Unexpected server error.' }); }
};
