import { currentModel, isConfigured } from './lib/engine.mjs';

const PROVIDER = () => (process.env.LLM_PROVIDER || 'ollama').toLowerCase();

export const handler = async () => ({
  statusCode: 200,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  body: JSON.stringify({ ok: true, version: '1.0.0', provider: PROVIDER(), model: currentModel(), configured: isConfigured() }),
});
