import { modelCall, validateText, currentModel, EXPLAIN_SYSTEM, explainUser } from './lib/engine.mjs';

const PROVIDER = () => (process.env.LLM_PROVIDER || 'ollama').toLowerCase();
const json = (statusCode, data) => ({
  statusCode,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  body: JSON.stringify(data),
});

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST.' });
  try {
    const body = JSON.parse(event.body || '{}');
    const topic = validateText(body.topic, 'Topic', 500);
    const source = typeof body.source === 'string' ? body.source.slice(0, 20000) : '';
    const level = typeof body.level === 'string' ? body.level.slice(0, 100) : 'Undergraduate engineering';
    const history = Array.isArray(body.history) ? body.history.slice(-6).map(m => ({ role: (m && m.role === 'user') ? 'user' : 'assistant', content: String((m && m.content) || '').slice(0, 1500) })) : [];
    const raw = await modelCall(EXPLAIN_SYSTEM, explainUser(topic, level, source, history), false, 4000);
    let explanation = String(raw || '').trim();
    if (/^```(?:md|markdown|text)?[ \t]*\n/i.test(explanation) && /\n?```\s*$/.test(explanation)) explanation = explanation.replace(/^```(?:md|markdown|text)?[ \t]*\n/i, '').replace(/\n?```\s*$/, '');
    explanation = explanation.slice(0, 8000);
    if (!explanation) throw new Error('The model returned an empty explanation.');
    return json(200, { explanation, topic, provider: PROVIDER(), model: currentModel() });
  } catch (e) { return json(e.status || 500, { error: e.message || 'Unexpected explanation error.' }); }
};
