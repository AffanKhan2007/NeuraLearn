import { modelCall, validateText, currentModel, CODE_SYSTEM, PDF_SUFFIX, VISUALIZE_SUFFIX } from './lib/engine.mjs';

const PROVIDER = () => (process.env.LLM_PROVIDER || 'ollama').toLowerCase();
const json = (statusCode, data) => ({
  statusCode,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  body: JSON.stringify(data),
});

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST.' });
  try {
    if (event.body && event.body.length > 1_000_000) return json(413, { error: 'Request too large.' });
    const body = JSON.parse(event.body || '{}');
    const topic = validateText(body.topic, 'Topic', 500);
    const source = typeof body.source === 'string' ? body.source.slice(0, 20000) : '';
    const level = typeof body.level === 'string' ? body.level.slice(0, 100) : 'Undergraduate engineering';
    const isPdf = body.pdf === true;
    const isViz = body.visualize === true;
    let system = isPdf ? CODE_SYSTEM + '\n\n' + PDF_SUFFIX : CODE_SYSTEM;
    if (isViz) system += '\n\n' + VISUALIZE_SUFFIX;
    const maxTokens = isPdf ? 16000 : (isViz ? 16000 : 8000);
    const user = `Create the complete executable NeuraLearn visual lesson now. Topic: ${topic}\nLearner level: ${level}\nSource notes (use as ground truth when supplied; do not invent conflicting details):\n${source || '(No source notes supplied)'}`;
    let html = '';
    let lastProblem = '';
    for (let attempt = 1; attempt <= 2; attempt++) {
      let raw = await modelCall(system, user, false, maxTokens);
      raw = String(raw || '').trim().replace(/^```(?:html)?\s*/i, '').replace(/\s*```$/, '');
      const start = raw.toLowerCase().indexOf('<!doctype html');
      html = start > 0 ? raw.slice(start) : raw;
      if (!/<html[\s>]/i.test(html) || !/<script[\s>]/i.test(html) || !/<\/html\s*>/i.test(html)) { lastProblem = 'incomplete HTML document'; html = ''; continue; }
      if (!html.includes('neuralelearn:lesson') || !html.includes('neuralelearn:beat')) { lastProblem = 'playback protocol messages'; html = ''; continue; }
      if (/<script[^>]+src\s*=/i.test(html) || /cdn\.jsdelivr\.net|unpkg\.com|[^a-z]konva/i.test(html)) { lastProblem = 'offline-safe SVG visuals (CDN script found)'; html = ''; continue; }
      if (!/<svg[\s>]/i.test(html) && !/<canvas[\s>]/i.test(html)) { lastProblem = 'inline SVG/canvas visuals'; html = ''; continue; }
      const runtimeTimed = /Math\.max\(\s*6000/i.test(html) && /\*\s*55?0/i.test(html);
      if (!runtimeTimed) {
        const pairs = [...html.matchAll(/narration:\s*("((?:[^"\\]|\\.)*)"|'((?:[^'\\]|\\.)*)')[\s\S]{0,600}?durationMs:\s*(\d+)/g)];
        const durs = pairs.length
          ? pairs.map(([, , dq, sq, dur]) => ({ words: (dq || sq || '').split(/\s+/).filter(Boolean).length, dur: Number(dur) }))
          : [...html.matchAll(/durationMs:\s*(\d+)/g)].map(([, dur]) => ({ words: 20, dur: Number(dur) }));
        // Lenient: accept if beats carry usable (>=6s) timings; only reject when
        // the majority are clearly too short. Strict flat-rejection wasted money.
        if (!durs.length) { lastProblem = 'readable beat timings'; html = ''; continue; }
        const bad = durs.filter(d => d.dur < Math.min(6000, d.words * 400));
        if (bad.length > Math.ceil(durs.length * 0.5)) { lastProblem = `rushed beat timing (${bad.length}/${durs.length} beats too short)`; html = ''; continue; }
      }
      lastProblem = '';
      break;
    }
    if (!html) return json(500, { error: `The model did not return a usable lesson (missing ${lastProblem}). Hit Retry to regenerate.` });
    if (html.length > 1_500_000) return json(500, { error: 'Generated lesson is too large. Please retry with a narrower topic.' });
    return json(200, { html, topic, provider: PROVIDER(), model: currentModel() });
  } catch (e) { return json(e.status || 500, { error: e.message || 'Unexpected code-generation error.' }); }
};
