import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';

test('server smoke test: health, static app, and request validation', async t => {
  const port = 4289;
  const child = spawn(process.execPath,['server.mjs'],{cwd:new URL('..',import.meta.url),env:{...process.env,PORT:String(port),LLM_PROVIDER:'ollama'},stdio:'ignore'});
  t.after(()=>child.kill());
  let health;
  for(let i=0;i<30;i++){
    try{const r=await fetch(`http://127.0.0.1:${port}/api/health`);if(r.ok){health=await r.json();break;}}catch{}
    await delay(100);
  }
  assert.equal(health?.ok,true);
  const page=await fetch(`http://127.0.0.1:${port}/`);
  assert.equal(page.status,200);
  assert.match(await page.text(),/NeuraLearn/);
  const bad=await fetch(`http://127.0.0.1:${port}/api/lesson`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({topic:''})});
  assert.equal(bad.status,400);
  assert.match((await bad.json()).error,/Topic is required/);
  const badCode=await fetch(`http://127.0.0.1:${port}/api/code-lesson`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({topic:''})});
  assert.equal(badCode.status,400);
  assert.match((await badCode.json()).error,/Topic is required/);
});
